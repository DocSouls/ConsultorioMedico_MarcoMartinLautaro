﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConsultorioMedico2.Data;
using ConsultorioMedico2.Models;
using Microsoft.EntityFrameworkCore;

namespace Consultorio.Desktop
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            CargarDatos();
        }

        private void CargarDatos()
        {

            try
            {
                using var db = new NuevoConsultorioDBcontext();
                //cargaara la lista de los paciente desde la base de datos
                var pacientes = db.Pacientes.ToList();
                dataGridView1.DataSource = pacientes;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al cargar los datos: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells["Id"]?.Value?.ToString() ?? "";
                textBox2.Text = row.Cells["Nombre"]?.Value?.ToString() ?? "";
                textBox3.Text = row.Cells["Email"]?.Value?.ToString() ?? "";
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        { 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //primero se deben validar los campos
            if
               (string.IsNullOrWhiteSpace(textBox2.Text) ||
               string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Por favor, complete todos los campos.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using var db = new NuevoConsultorioDBcontext();
            var paciente = new Paciente
            {
                Nombre = textBox2.Text.Trim(),
                Email = textBox3.Text.Trim(),
            };

            db.Pacientes.Add(paciente);
            db.SaveChanges();

            MessageBox.Show("Paciente agregado exitosamente.", "Éxito",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            LimpiarCampos();
            CargarDatos();
        }
        

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Validar que se haya seleccionado un ID
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Por favor, seleccione un Paciente a actualizar.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validar campos
                if (string.IsNullOrWhiteSpace(textBox2.Text) ||
                    string.IsNullOrWhiteSpace(textBox3.Text))
                {
                    MessageBox.Show("Por favor, complete todos los campos.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBox1.Text, out int id))
                {
                    MessageBox.Show("ID debe ser de números válidos.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using var db = new ConsultorioDBcontext();
                var paciente = db.Paciente.Find(id);

                if (paciente != null)
                {
                    paciente.Nombre = textBox2.Text.Trim();
                    paciente.Email = textBox3.Text.Trim();

                    db.SaveChanges();

                    MessageBox.Show("Paciente actualizado exitosamente.", "Éxito",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);

                    LimpiarCampos();
                    CargarDatos();
                }
                else
                {
                    MessageBox.Show("No se encontró el Paciente con el ID especificado.", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al actualizar el Paciente: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                // que se haya seleccionado un ID
                if (string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    MessageBox.Show("Por favor, seleccione un Paciente para eliminar.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(textBox1.Text, out int id))
                {
                    MessageBox.Show("ID debe ser un número válido.", "Validación",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var resultado = MessageBox.Show("¿Está seguro de que desea eliminar la informacion de este Paciente?",
                    "Confirmar Eliminación", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (resultado == DialogResult.Yes)
                {
                    using var db = new NuevoConsultorioDBcontext();
                    var paciente = db.Pacientes.Find(id);

                    if (paciente != null)
                    {
                        db.Pacientes.Remove(paciente);
                        db.SaveChanges();

                        MessageBox.Show("Paciente eliminado exitosamente.", "Éxito",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

                        LimpiarCampos();
                        CargarDatos();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró el Paciente con el ID especificado.", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al eliminar al Paciente: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void LimpiarCampos()
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
    }
}
