﻿namespace ConsultorioMedico2
{
    public class Form1
    {
    }
}
