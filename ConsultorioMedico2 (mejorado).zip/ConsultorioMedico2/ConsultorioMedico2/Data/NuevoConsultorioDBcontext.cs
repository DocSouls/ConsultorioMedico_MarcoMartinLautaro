﻿using Microsoft.EntityFrameworkCore;
using ConsultorioMedico2.Models;

namespace ConsultorioMedico2.Data
{
    public class NuevoConsultorioDBcontext : DbContext
    {
        //este constructor sin pparametross esta para usarse en los forms
        public NuevoConsultorioDBcontext()
        {
        }




        public NuevoConsultorioDBcontext(DbContextOptions<NuevoConsultorioDBcontext> options) : base (options) 
        { 
        }
        public DbSet<Paciente> Pacientes { get; set; }

        public DbSet<Doctores> Doctores { get; set; }

        public DbSet<Turnos> Turnos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS;Database=ConsultorioMedico;Trusted_Connection=True;Encrypt=False;");
            }
        }
    }
}