﻿namespace ConsultorioMedico2.Models
{
    public class Turnos
    {
        public int Id { get; set; }
        public string Doctor { get; set; } = string.Empty;

        public string Paciente { get; set; } = string.Empty;
        public DateTime Fecha { get; set; }

        public Turnos(int id, string doctor, string paciente, DateTime fecha)
        {
            Id = id;
            Doctor = doctor;
            Paciente = paciente;
            Fecha = fecha;

        }
    }
}
